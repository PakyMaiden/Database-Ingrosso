-- Autista

GRANT CONNECT, CREATE SESSION      TO Autista;
GRANT EXECUTE ON Numero_Ordini     TO Autista; -- procedura
GRANT SELECT ON Autisti_Spedizioni TO Autista; -- vista
