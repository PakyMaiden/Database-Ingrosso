-- Magazziniere

GRANT CONNECT, CREATE SESSION              TO Magazziniere;
GRANT EXECUTE ON Calcola_Totale            TO Magazziniere; -- procedura
GRANT SELECT ON Lista_Magazzinieri_Reparti TO Magazziniere; -- vista
