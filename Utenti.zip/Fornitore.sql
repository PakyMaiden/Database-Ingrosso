-- Fornitore

GRANT CONNECT, CREATE SESSION    TO Fornitore;
GRANT EXECUTE ON Avvia_Fornitura TO Fornitore; -- procedura
